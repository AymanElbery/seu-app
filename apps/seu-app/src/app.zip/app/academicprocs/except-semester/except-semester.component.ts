import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-except-semester',
  templateUrl: './except-semester.component.html',
  styleUrls: ['./except-semester.component.scss']
})
export class ExceptSemesterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
