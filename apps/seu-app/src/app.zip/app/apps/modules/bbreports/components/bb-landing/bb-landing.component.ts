import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bb-landing',
  templateUrl: './bb-landing.component.html',
  styleUrls: ['./bb-landing.component.css']
})
export class BbLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
