import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bb-home',
  templateUrl: './bb-home.component.html',
  styleUrls: ['./bb-home.component.css']
})
export class BbHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
