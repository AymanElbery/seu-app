import { NgModule } from '@angular/core';

@NgModule({
  declarations: [],
  imports: [
  ],
  providers: []
})
export class BBServicesModule {
}

