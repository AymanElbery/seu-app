import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-footer-en',
  templateUrl: './contact-footer-en.component.html',
  styleUrls: ['./contact-footer-en.component.css']
})
export class ContactFooterEnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
