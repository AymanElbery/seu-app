import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apps-footer',
  templateUrl: './apps-footer.component.html',
  styleUrls: ['./apps-footer.component.css']
})
export class AppsFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
