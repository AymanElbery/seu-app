export interface Credentials {

    ssn: string;
    


}
