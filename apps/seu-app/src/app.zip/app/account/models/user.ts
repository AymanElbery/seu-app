export class User {

    public givenName: string;
    public familyName: string;

    public email: string;

    public groups: string[];

}
