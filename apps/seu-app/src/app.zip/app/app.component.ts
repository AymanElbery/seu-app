import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from './account/services/user.service';
import { environment } from 'src/environments/environment';
import { Router, ActivatedRoute, Route } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

import { OAuthService, JwksValidationHandler } from 'angular-oauth2-oidc';
import { oAuthDevelopmentConfig } from './oauth.config';
import { Observable } from 'rxjs';
import { AuthService } from './account/services/auth.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  signedIn: Observable<boolean>;


  constructor(public userService: UserService, private http: HttpClient,
    private oAuthService: OAuthService,private authService: AuthService,private router:Router,
    private route: Router, private activatedRoute: ActivatedRoute, private translate: TranslateService
  ) {
    this.activatedRoute.queryParams
      .subscribe(params => {
        if (params.lang) {
          this.setLang(params.lang);
        }
      });

    // this.http.jsonp(environment.ssolink + '/sess.php', "callback").subscribe(
    //   res => {
    //     localStorage.setItem('sid', encodeURI(res['csid']));
    //     this.userService.loadUserData();
    //   },
    //   error => {
    //     this.userService.relogin();
    //   });
  }
  setLang(ulang) {
    let lang = 'ar';
    if (ulang == 'en' || ulang == 'ar') {
      lang = ulang;
    }
    localStorage.setItem('seu-lang', lang);
    this.translate.use(lang);
  }

  ngOnInit() {
    this.oidc();

    this.signedIn = this.authService.isSignedIn();

    this.authService.userChanged().subscribe(
        (user) => {
            console.log("USER CHECNGED",user);
        });
  }
  custionsso() {
    this.http.jsonp(environment.ssolink + '/sess.php', "callback").subscribe(
      res => {
        localStorage.setItem('sid', encodeURI(res['csid']));
        this.userService.loadUserData();
      },
      err => {
        const notapps = (document.location.href.indexOf("/apps") == -1) ? true : false;
        const notpublic = (document.location.href.indexOf("/public") == -1) ? true : false;
        const notcontactus = (document.location.href.indexOf("/contactus") == -1) ? true : false;
        if (notapps && notpublic && notcontactus) {
          this.userService.relogin();
        }
      }
    );
  }

  oidc() {
    this.oAuthService.configure(oAuthDevelopmentConfig);
    let url: string = "https://iamtest.seu.edu.sa/.well-known/oidc-configuration";
    this.oAuthService.setStorage(sessionStorage);
    this.oAuthService.tokenValidationHandler = new JwksValidationHandler();

    // Loads discovery document & tries login.
    this.oAuthService.loadDiscoveryDocument(url).then((doc: any) => {
      // Stores discovery document.
      this.authService.setItem('discoveryDocument', doc.info.discoveryDocument);
      // Tries login.
      this.oAuthService.tryLogin({
        onTokenReceived: context => {
          // Loads user profile.
          this.oAuthService.loadUserProfile().then(() => {
            this.authService.init();

            // Gets the redirect URL.
            // If no redirect has been set, uses the default.
            const redirect: string = this.authService.getItem('redirectUrl')
              ? this.authService.getItem('redirectUrl')
              : '/home';
            // Redirects the user.
            this.router.navigate([redirect]);
          });
        }
      }).then(() => {
        // Manages consent error.
        if (window.location.search && window.location.search.match(/\^?error=consent_required/) != null) {
          this.router.navigate(['/forbidden']);
        }
      });
    });

    // Setups silent refresh.
    this.oAuthService.setupAutomaticSilentRefresh();

    // Events.
    // On silently refreshed.
    // this.oAuthService.events.filter(e => e.type === 'silently_refreshed').subscribe(e => {
    //   this.oAuthService.loadUserProfile();
    // });

    // // On session terminated.
    // this.oAuthService.events.filter(e => e.type === 'session_terminated').subscribe(e => {
    //   this.authService.refreshSession();
    // });

    // Already authorized.
    if (this.oAuthService.hasValidAccessToken()) {
      this.authService.init();
    }

  }

}
