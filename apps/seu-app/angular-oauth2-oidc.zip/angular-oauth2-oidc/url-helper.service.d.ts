export declare class UrlHelperService {
    getHashFragmentParams(customHashFragment?: string): object;
    parseQueryString(queryString: string): object;
}
