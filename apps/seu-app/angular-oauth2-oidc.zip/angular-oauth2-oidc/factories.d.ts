export declare function createDefaultLogger(): Console;
export declare function createDefaultStorage(): Storage;
