export declare function b64DecodeUnicode(str: any): string;
export declare function base64UrlEncode(str: any): string;
